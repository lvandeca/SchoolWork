#include "student.h"
#include <stdlib.h>
#include <string.h>

void freeStudent(Student *a) {
}

Student *getStudent(FILE *fd) {
}

void printStudent(Student *a, FILE *fd) {
}
