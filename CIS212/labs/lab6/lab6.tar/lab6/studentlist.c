#include "studentlist.h"
#include <stdlib.h>
#include <string.h>

static void st_destroy(const StudentList *al) {
}

static bool st_add(const StudentList *al, Student *a) {
}

static bool st_get(const StudentList *al, long index, Student **aptr) {
}

static long st_size(const StudentList *al) {
}

static StudentList template = {
};

#define UNUSED __attribute__((unused))
static void doNothing(UNUSED void *x) {
}

const StudentList *StudentList_create(long capacity, void (*freeV)(void*)) {
}
