#include "ADTs/stack.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

void palindrome(FILE *fp, const Stack *st){
	
}


int main(int argc, char *argv[]){
	FILE * fp = NULL;
	const Stack * st = Stack_create(free);
	int exitStatus = EXIT_FAILURE;


	exitStatus = EXIT_SUCCESS;


cleanup:
	if(st != NULL)
		st->destroy(st);
	if(fp != NULL)
		fclose(fp);
	return exitStatus;
}
